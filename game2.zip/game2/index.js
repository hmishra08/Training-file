var dice,activeplayer,netscore;
var scores=[0,0];
netscore=0;
console.log(dice);
activeplayer=0;
document.getElementById("score-0").innerHTML="0";
document.getElementById("score-1").innerHTML="0";
document.getElementById("current-0").innerHTML="0";
document.getElementById("current-1").innerHTML="0";
document.querySelector(".dice0").style.display="none";
document.querySelector(".dice1").style.display="none";
var active0=document.getElementById("p0");
var active1=document.getElementById("p1");
active1.style.display="none";
function f1()
{
    var dice0=Math.floor(Math.random()*6)+1;
    var dice1=Math.floor(Math.random()*6)+1;
    document.querySelector("#current-"+activeplayer).textContent=dice0+dice1;
    var dicedom0=document.querySelector(".dice0");
    dicedom0.style.display="block";
    var dicedom1=document.querySelector(".dice1");
    dicedom1.style.display="block";
    dicedom0.src=dice0+".jpg";
    dicedom1.src=dice1+".jpg";
    if(dice0!==1 && dice1!==1)
    {
        netscore=netscore+dice0+dice1;
        document.getElementById("current-"+activeplayer).innerHTML=netscore;
    }
    else
    {
       //activeplayer===0 ? activeplayer=1 :activeplayer=0;
       if(activeplayer===0)
       {
           activeplayer=1;
           active0.style.display="none";
           active1.style.display="block";
       }
       else
       {
           activeplayer=0;
           active0.style.display="block";
           active1.style.display="none";
       }
       netscore=0;
       document.getElementById("current-0").innerHTML="0";
        document.getElementById("current-1").innerHTML="0";
    }

}
function f2()
{
    scores[activeplayer]=scores[activeplayer]+netscore;
    document.getElementById("score-"+activeplayer).innerHTML=scores[activeplayer];
    netscore=0;
       document.getElementById("current-0").innerHTML="0";
        document.getElementById("current-1").innerHTML="0";
    //activeplayer===0 ? activeplayer=1:activeplayer=0;
    if(activeplayer===0)
       {
           activeplayer=1;
           active0.style.display="none";
           active1.style.display="block";
       }
       else
       {
           activeplayer=0;
           active0.style.display="block";
           active1.style.display="none";
       }
    if(scores[0]>=100)
    {
        alert("Player 1 won");
    }
    if(scores[1]>=100)
    {
        alert("Player 2 won");
    }
}
function f3()
{
    document.getElementById("score-0").innerHTML="0";
    document.getElementById("score-1").innerHTML="0";
    document.getElementById("current-0").innerHTML="0";
    document.getElementById("current-1").innerHTML="0";
    document.querySelector(".dice0").style.display="none";
    document.querySelector(".dice1").style.display="none";
    netscore=0;
    scores[0]=0;
    scores[1]=0;
}
