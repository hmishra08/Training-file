import { Component, OnInit,Input } from '@angular/core';
import {AppServiceService} from '../app-service.service';
@Component({
  selector: 'app-question3',
  templateUrl: './question3.component.html',
  styleUrls: ['./question3.component.css']
})
export class Question3Component implements OnInit {

 constructor(private ques3service:AppServiceService) { }
  ques3:any;
  quesNo:number=2;
  answer3:string;
  Score3:number=0;
  temp:number=0;
  next:number=0;
  ngOnInit() 
  {
    this.ques3service.getfile('/assets/question3.json').subscribe(data=>{this.ques3=data
      //alert(this.ques1.ques);
      //alert(this.ques1.options);
      this.answer3=this.ques3.answer;
  });
}
f2(x)
{
  this.temp=1;
  //alert(x);
  if(x==this.answer3)
  {
    this.Score3=this.Score3+1;
    
  }
  //alert("Score is "+this.Score3);
  //this.ques3service.giveAnswer(this.Score3);
  this.ques3service.getAnswer(x,this.answer3,this.quesNo);
}
f3()
{
  if(this.temp==1)
  {
    this.next=1;
  }
  else
  {
    alert("please select the option");
  }
}

}
