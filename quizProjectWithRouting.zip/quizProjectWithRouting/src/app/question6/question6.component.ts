import { Component, OnInit,Input } from '@angular/core';
import {AppServiceService} from '../app-service.service';

@Component({
  selector: 'app-question6',
  templateUrl: './question6.component.html',
  styleUrls: ['./question6.component.css']
})
export class Question6Component implements OnInit {

  constructor(private ques6service:AppServiceService) { }
  ques6:any;
  quesNo:number=5;
  answer6:string[]=[];
  Score6:number=0;
  answer6submit:string[]=[];
  temp:number=0;
  next:number=0;
  ngOnInit() 
  {
    this.ques6service.getfile('/assets/question6.json').subscribe(data=>{this.ques6=data
      //alert(this.ques1.ques);
      //alert(this.ques1.options);
      this.answer6=this.ques6.answer;
      //console.log(this.answer6);
  });
}
f2(x:string)
{
  this.temp=1;
  //alert(x);
  this.answer6submit.push(x);
  
  
}
f3()
{
  //let temp=0;
  //console.log(this.answer6submit);
  /*if(this.answer6submit.length==this.answer6.length)
  {
    //console.log("length true");
    //console.log(this.answer6submit[0]);
      //console.log(this.answer6[0]);
    for(let i=0;i<this.answer6.length;i++)
    {
      console.log(this.answer6submit[i]);
      console.log(this.answer6[i]);
      if(this.answer6submit[i]==this.answer6[i])
      {
          temp=temp+1;
          //console.log(temp);
          //console.log("true");
        }
    }
    if(temp==this.answer6.length)
    {
    this.Score6+=1;
    
    }
    
  }
  
  else
  {
    console.log("false");
  }*/
  
  if(this.temp==1)
  {
    //alert(this.Score6);
    //this.ques6service.giveAnswer(this.Score6);
    this.ques6service.getAnswer(this.answer6submit,this.answer6,this.quesNo);
    this.next=1;
  }
  else
  {
    alert("please select the option");
  }
}

}