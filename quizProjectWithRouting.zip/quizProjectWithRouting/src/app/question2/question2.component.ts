import { Component, OnInit,Input } from '@angular/core';
import {AppServiceService} from '../app-service.service';
@Component({
  selector: 'app-question2',
  templateUrl: './question2.component.html',
  styleUrls: ['./question2.component.css']
})
export class Question2Component implements OnInit {

 constructor(private ques2service:AppServiceService) { }
  ques2:any;
  quesNo:number=1;
  answer2:string;
  Score2:number=0;
  temp:number=0;
  next:number=0;
  ngOnInit() 
  {
    this.ques2service.getfile('/assets/question2.json').subscribe(data=>{this.ques2=data
      //alert(this.ques1.ques);
      //alert(this.ques1.options);
      this.answer2=this.ques2.answer;
  });
}
f2(x)
{
  this.temp=1;
  //alert(x);
  if(x==this.answer2)
  {
    this.Score2=this.Score2+1;
    
  }
  //alert("Score is "+this.Score2);
  //this.ques2service.giveAnswer(this.Score2);
   this.ques2service.getAnswer(x,this.answer2,this.quesNo);
}
f3()
{
  if(this.temp==1)
  {
    this.next=1;
  }
  else
  {
    alert("please select the option");
  }
}

}
