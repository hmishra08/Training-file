import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class AppServiceService {

  constructor(private _http:HttpClient) { }
  getfile(x:string)
  {
      return this._http.get(x);
  }
  TotalScore:number=0;
  submittedAnswer:any[]=[];
  correctAnswer:any[]=[];
  temp:number=0;
  giveAnswer(score:number)
  {
    this.TotalScore=this.TotalScore+score;
    alert("Total Score "+this.TotalScore);
  }
  getAnswer(sAnswer:any,cAnswer:any,quesNo:number)
  {
      this.submittedAnswer[quesNo]={"sA":sAnswer};
      //console.log("submitted answer="+this.submittedAnswer[quesNo].sA);
      this.correctAnswer[quesNo]={"cA":cAnswer};
      //console.log("correct answer="+this.correctAnswer[quesNo].cA);
      //console.log(this.submittedAnswer.length);
  }
  score():number
  {
    for(var i=1;i<=this.submittedAnswer.length;i++)
    {
      //console.log(i-1);
      //console.log(this.correctAnswer[i-1].cA);
      //console.log(this.submittedAnswer[i-1].sA);
      if(i<6)
      {
      if(this.submittedAnswer[i-1].sA==this.correctAnswer[i-1].cA)
      {
        this.TotalScore+=1;
        
      }
      //console.log(this.TotalScore);
    }
    else
    {
      //console.log('enter');
      //console.log(this.correctAnswer[i-1].cA.length);
      for(var j=1;j<=this.correctAnswer[i-1].cA.length;j++)
      {
        //console.log(this.correctAnswer[i-1].cA[j-1]);
        //console.log(this.submittedAnswer[i-1].sA[j-1]);
        if(this.correctAnswer[i-1].cA.length==this.submittedAnswer[i-1].sA.length)
        {
        if(this.submittedAnswer[i-1].sA[j-1]==this.correctAnswer[i-1].cA[j-1])
      {
        this.temp+=1;
        //this.TotalScore+=1;
      }
      
    }
    if(this.temp==this.correctAnswer[i-1].cA.length)
    {
      this.TotalScore+=1;
    }
    //console.log(this.TotalScore);
      }
    }
    }
    //alert("Total Score="+ this.TotalScore);
    return this.TotalScore;
  }
  }

