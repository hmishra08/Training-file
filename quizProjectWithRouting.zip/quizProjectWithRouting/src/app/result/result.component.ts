import { Component, OnInit } from '@angular/core';
import {AppServiceService} from '../app-service.service';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  constructor(private resultservice:AppServiceService) { }
  finalScore:number=0;

  ngOnInit() 
  {
    this.finalScore=this.resultservice.score();
    //alert(this.finalScore);
  }

}
