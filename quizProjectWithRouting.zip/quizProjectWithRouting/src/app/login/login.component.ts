import { Component, OnInit } from '@angular/core';
import {AppServiceService} from '../app-service.service';
import { RouterModule,Routes,Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service:AppServiceService,private router:Router) { }
  id:string;
  passw:string;
  data:any;
  temp:number=0;
  ngOnInit() 
  {
    this.service.getfile('/assets/loginDetail.json').subscribe(detail=>{this.data=detail});
    
  }
  
  f1()
  {
   
    for(var i=0;i<this.data.length;i++)
    {
      if(this.data[i].id==this.id && this.data[i].password==this.passw)
      {
          this.temp=1;
      }
    }
    console.log(this.temp);
    if(this.temp==1)
    {
      alert('Login Successful');
      this.router.navigate(['/sample']);
      
    }
    else
    {
      alert('Login Failed');
    }
  }
}
