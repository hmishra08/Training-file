import { Component, OnInit,Input } from '@angular/core';
import {AppServiceService} from '../app-service.service';

@Component({
  selector: 'app-question5',
  templateUrl: './question5.component.html',
  styleUrls: ['./question5.component.css']
})
export class Question5Component implements OnInit {

  constructor(private ques5service:AppServiceService) { }
  ques5:any;
   quesNo:number=4;
  answer5:string;
  Score5:number=0;
  temp:number=0;
  next:number=0;
  ngOnInit() 
  {
    this.ques5service.getfile('/assets/question5.json').subscribe(data=>{this.ques5=data
      //alert(this.ques1.ques);
      //alert(this.ques1.options);
      this.answer5=this.ques5.answer;
  });
}
f2(x)
{
  this.temp=1;
  //alert(x);
  if(x==this.answer5)
  {
    this.Score5=this.Score5+1;
    
  }
  //alert("Score is "+this.Score5);
  //this.ques5service.giveAnswer(this.Score5);
  this.ques5service.getAnswer(x,this.answer5,this.quesNo);
}
f3()
{
  if(this.temp==1)
  {
    this.next=1;
  }
  else
  {
    alert("please select the option");
  }
}

}

