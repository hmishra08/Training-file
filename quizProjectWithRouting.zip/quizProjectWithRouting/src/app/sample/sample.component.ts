import { Component, OnInit } from '@angular/core';
import { RouterModule,Routes,Router } from '@angular/router';
@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
    this.router.navigate(["/rules"])
  }

}
