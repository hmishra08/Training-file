function f1()
    {
        var name=document.getElementById("id").value;
        var pass=document.getElementById("passw").value;
        var temp=0;
        console.log(name+" "+pass);
        $.get("logininfo.json",function(d,r){
        console.log(d.id);
        console.log(d.pasw);
        console.log(d.id.length);
        for(var i=0;i<d.id.length;i++)
        {
            console.log(d.id[i]);
            console.log(d.pasw[i]);
            if(name==d.id[i] && pass==d.pasw[i])
            {
                console.log("find");
                $("#page1").load(insurancetype.html);
                //break;
                temp=1;
            }
        }});
        console.log(temp);
            if(temp==0)
            {
                document.getElementById("error1").innerHTML="<p style='color:red'>Your id or password is not correct</p>";
            }
        
    }