var dice,activeplayer,netscore;
var scores=[0,0];
netscore=0;
console.log(dice);
activeplayer=0;
document.getElementById("score-0").innerHTML="0";
document.getElementById("score-1").innerHTML="0";
document.getElementById("current-0").innerHTML="0";
document.getElementById("current-1").innerHTML="0";
document.querySelector(".dice").style.display="none";
var active0=document.getElementById("p0");
var active1=document.getElementById("p1");
active1.style.display="none";
function f1()
{
    var dice=Math.floor(Math.random()*6)+1;
    document.querySelector("#current-"+activeplayer).textContent=dice;
    var dicedom=document.querySelector(".dice");
    dicedom.style.display="block";
    dicedom.src=dice+".jpg";
    if(dice!==1)
    {
        netscore=netscore+dice;
        document.getElementById("current-"+activeplayer).innerHTML=netscore;
    }
    else
    {
       //activeplayer===0 ? activeplayer=1 :activeplayer=0;
       if(activeplayer===0)
       {
           activeplayer=1;
           active0.style.display="none";
           active1.style.display="block";
       }
       else
       {
           activeplayer=0;
           active0.style.display="block";
           active1.style.display="none";
       }
       netscore=0;
       document.getElementById("current-0").innerHTML="0";
        document.getElementById("current-1").innerHTML="0";
    }

}
function f2()
{
    scores[activeplayer]=scores[activeplayer]+netscore;
    document.getElementById("score-"+activeplayer).innerHTML=scores[activeplayer];
    netscore=0;
       document.getElementById("current-0").innerHTML="0";
        document.getElementById("current-1").innerHTML="0";
    //activeplayer===0 ? activeplayer=1:activeplayer=0;
    if(activeplayer===0)
       {
           activeplayer=1;
           active0.style.display="none";
           active1.style.display="block";
       }
       else
       {
           activeplayer=0;
           active0.style.display="block";
           active1.style.display="none";
       }
    if(scores[0]>=50)
    {
        alert("Player 1 won");
    }
    if(scores[1]>=50)
    {
        alert("Player 2 won");
    }
}
function f3()
{
    document.getElementById("score-0").innerHTML="0";
    document.getElementById("score-1").innerHTML="0";
    document.getElementById("current-0").innerHTML="0";
    document.getElementById("current-1").innerHTML="0";
    document.querySelector(".dice").style.display="none";
}