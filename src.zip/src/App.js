import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Projects from './components/projects';
import AddProject from './components/AddProject';
import Todos from './components/todos';
import uuid from 'uuid';
import $ from 'jquery';

class App extends Component {
  constructor() {
        super()
        this.state={
          projects:[]
        }
      }
 
handleAddProject(newProj)
{
  alert("data submitted to app");
  //console.log("data submited is"+newProj)
  let project=this.state.projects;
  project.push(newProj);
  this.setState({projects:project})
}

handelDeleteProject(id)
{
    console.log("final function "+id);
    let allProjects=this.state.projects;
    let index=allProjects.findIndex(oneproject=>oneproject.id==id);
    allProjects.splice(index,1);
    this.setState({projects:allProjects})
}

 componentWillMount()
 {
   console.log("component will....mount...")
   this.setState({
          projects:[
            {
              id:uuid.v4(),
              title:'Business website',
              category:'web design'
            },
             {
               id:uuid.v4(),
              title:'Social app',
              category:'Mobile Development'
            },
             {
              id:uuid.v4(),
              title:'Ecommerce shoipng',
              category:'web Devlopment'
            }
          ]
        })
 }
 componentDidMount()
 {
   this.getTodos()
 }

getTodos()
{
  $.ajax({
    url:'https://jsonplaceholder.typicode.com/todos',
    dataType:'json',
    cache:false,
    success:function(data)
    {
        this.setState({todos:data},function(){
          console.log("Download todos::::::::::");
          console.log(data)
        });
    }.bind(this)
  });
}

  render() {
    return (
      
      <div>
        <AddProject onAddProject={this.handleAddProject.bind(this)}></AddProject>
        <Projects ProjectsFromApp={this.state.projects} test="Hello world" onDelete={this.handelDeleteProject.bind(this)}/>
        <Todos onData={this.state.projects}></Todos>
      </div>
      
    );
  }
}

export default App;
