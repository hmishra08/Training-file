import React, { Component } from 'react';
import uuid from 'uuid';
import PropTypes from 'prop-types';

class AddProject extends Component {

    constructor()
    {
        super();
        this.state={
            newProject:{}
        }
    }
  
  

  static defaultProps={
      categories:['Web Design','Web Devlopment','Mobile Devlopment']
  }
  handleSubmit(e)
  {
      if(this.refs.title.value=='')
      {
          alert("Title should not be empty");
      }
      else{
      console.log('Submitted'+this.refs.title.value);
      this.setState({
            newProject:{
                id:uuid.v4,
                title:this.refs.title.value,
                category:this.refs.category.value
            }
        },function(){
            console.log("new state"+this.state);
            this.props.onAddProject(this.state.newProject);
        });
      

      }
      
      e.preventDefault();
  }

  render() {
      let categoryoptions=this.props.categories.map(
          oneCategory=>{
              return <option key={oneCategory} value={oneCategory}>{oneCategory}</option>
          }
      )
    return (
        <div>
            <h3>Add Projects</h3>
            <form onSubmit={this.handleSubmit.bind(this)}>
                <div>
                    <label>Title</label><br/>
                    <input type="text" ref='title'/>
                </div>


                <div>
                    <label>category</label><br/>
                    <select ref='category'>
                        {categoryoptions}
                    </select>
                </div>
                <input type="submit"/>
            </form>
        </div>
    );
  }
}



export default AddProject;
