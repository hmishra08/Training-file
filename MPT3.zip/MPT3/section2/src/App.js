import React, { Component } from 'react';
import Registeration from './components/registeration';

class App extends Component {

constructor()
{
  super();
  this.state={
    customerDetails:[]
  }
}

handleCustomer(details)
{
  //alert("handle in app called");
  console.log(details);
  let newDetails=this.state.customerDetails;
  newDetails.push(details);
  //console.log("new details=="+newDetails.name);
  this.setState({
          customerDetails:newDetails
  },function()
  {
    console.log("customer Details===="+this.state.customerDetails[0].name)
  });
}

handleDelete(name)
{
  alert("name to deleted"+name);
  let newdata=this.state.customerDetails;
  console.log(newdata);
  //let index=this.state.customerDetails.findIndex(onedetail=>{onedetail.name===name})
  let index;
  for(var i=0;i<newdata.length;i++)
  {
        if(newdata[i].name==name)
        {
          index=i;
        }
  }

  //alert(index);
  newdata.splice(index,1);
  this.setState({customerDetails:newdata})
  
}
  render() {
    return (
      <div class="container">
        <Registeration handle={this.handleCustomer.bind(this)} data={this.state.customerDetails} DeleteInfo={this.handleDelete.bind(this)}/>
      </div>
    );
  }
}

export default App;
