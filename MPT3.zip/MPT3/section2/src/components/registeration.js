import React, { Component } from 'react';


class Registeration extends Component {

    constructor()
    {
        super();
        this.state={
            customer:{}
        }
    }

    addCustomer(e)
    {
            //alert("add function called");
            this.setState({
                customer:{
                    name:this.refs.cName.value,
                    email:this.refs.cEmail.value,
                    number:this.refs.cNumber.value,
                    address:this.refs.cAddress.value,
                    visit:this.refs.cVisit.value,
                    date:this.refs.cDate.value,
                }
            },function(){
                console.log(this.state.customer);
                this.props.handle(this.state.customer);
                this.refs.cName.value="";
                this.refs.cEmail.value="";
                this.refs.cNumber.value="";
                this.refs.cAddress.value="";
                this.refs.cVisit.value="";
                this.refs.cDate.value="";
            })
            e.preventDefault();
    }

    handle(name)
    {
        //alert(name);
        this.props.DeleteInfo(name);
    }

  render() {
      let details;
      details=this.props.data.map(
          onedetail=>{
              return(
                  <div>
              <tr>
                  <td>Name: </td>
              <td>{onedetail.name}</td>
              </tr>
              <tr>
                  <td>Email id: </td>
              <td>{onedetail.email}</td>
              </tr>
              <tr>
                  <td>Mobile Number: </td>
              <td>{onedetail.number}</td>
              </tr>
              <tr>
                  <td>Address: </td>
              <td>{onedetail.address}</td>
              </tr>
              <tr>
                  <td>description/Purpose: </td>
              <td>{onedetail.visit}</td>
              </tr>
              <tr>
                  <td>Date of visit: </td>
              <td>{onedetail.date}</td>
              </tr>
              <button class='btn btn-warning' onClick={this.handle.bind(this,onedetail.name)}>Delete</button>
              </div>
              )
          }
      )
    return (
      <div>
          <div class="jumbotron">
              <h1 align="center">Customer Registeration Form</h1>
          <form class="form form-condensed" onSubmit={this.addCustomer.bind(this)}>
              <table class="table table-striped table-condensed">
                 
            <tr><td><input type="text" name="name" class="form-control" ref="cName" placeholder="Username"/></td></tr>
            </table>
            <table class="table table-striped table-condensed">
            <tr><td><input type="email" name="email" class="form-control" ref="cEmail" placeholder="Email id"/></td></tr>
            </table>
            <table class="table table-striped table-condensed">
            <tr><td><input type="number" name="mobile" class="form-control" ref="cNumber" placeholder="Mobile Number"/></td></tr>
             </table>
            <table class="table table-striped table-condensed">
            <tr><td><input type="text" name="address" class="form-control" ref="cAddress" placeholder="Address"/></td></tr>
             </table>
            <table class="table table-striped table-condensed">
            <tr><td><input type="text" name="visit" class="form-control" ref="cVisit" placeholder="Purpose of visit"/></td></tr>
             </table>
            <table class="table table-striped table-condensed">
            <tr><td><input type="text" name="date" class="form-control" ref="cDate" placeholder="date of Visit"/></td></tr>
             </table>
            <table class="table table-striped table-condensed">
            <tr><td><input type="submit" class="btn btn-success form-control"  value="Add"/></td></tr>
            </table>
          </form>
          </div>

          <div id="d1">
                <h2>Customers visit Information</h2>
                <hr/>
                {details}
          </div>
      </div>
    );
  }
}

export default Registeration;
