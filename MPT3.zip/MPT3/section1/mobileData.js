var express=require('express');
var app=express();
var fr=require('fs');
var cors=require('cors');
var parser=require('body-parser');

//-----------------to display all mobiles list------------------------//
app.get('/display',(req,res)=>{
   res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    var data=JSON.parse(fr.readFileSync('mobile.json'));
    res.send(data);
    console.log(data);
});


//-----------------to display all mobiles list of price range 10,000 to 50,000------------------------//
app.get('/displayRange',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    var data=JSON.parse(fr.readFileSync('mobile.json'));
    var newdata=[];
    for(var i=0;i<data.length;i++)
    {
        if(data[i].mobPrice>=10000&&data[i].mobPrice<=50000)
        {
            
            newdata.push(data[i]);
        }
    }
    res.send(newdata);
    console.log(newdata);
});


//-----------------Updating mobile name based on Id 1002------------------------//
app.get('/update/:newName',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    var newName1=req.params.newName;
    var data=JSON.parse(fr.readFileSync('mobile.json'));
    for(var i=0;i<data.length;i++)
    {
        if(data[i].mobId==1002)
        {
            data[i].mobName=newName1;
        }
    }
    fr.writeFileSync('mobile.json',JSON.stringify(data));
    res.send(data);
    console.log(data);
});

//-----------------Adding a new mobile------------------------//
app.get('/addMobile/:id/:name/:price',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    var mobId=req.params.id;
    var mobName=req.params.name;
    var mobPrice=req.params.price;
    var data=JSON.parse(fr.readFileSync('mobile.json'));
    data.push(
        {
            mobId,mobName,mobPrice
        }
    );
    fr.writeFileSync('mobile.json',JSON.stringify(data));
    res.send(data);
    console.log(data);
})

app.use(cors()).listen(1234,()=>{
    console.log("running");
})