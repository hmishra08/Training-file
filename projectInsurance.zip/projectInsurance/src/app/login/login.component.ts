import { Component, OnInit } from '@angular/core';
import{LoginService} from '../login.service';
import{InsuranceTypeComponent} from '../insurance-type/insurance-type.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

 
  constructor(private service:LoginService){}
  
  
    id:string;
    password:string;
    temp:number=0;
    data:any;
      /*{"id":"a1","password":"aaa111"},
     {"id":"a2","password":"aaa222"},
     {"id":"a3","password":"aaa333"},
    {"id":"a4","password":"aaa444"}

    ]*/
 
    //constructor(private _productService:loginService){}
    ngOnInit():void
    {
        //this._productService.getProducts('api/products/loginDetail.json').subscribe(products=>this.data=products);
        this.service.getfile('/assets/loginDetail.json').subscribe(data=>{
        this.data=data
        console.log(this.data);
      });
        
    }

 f1()
 {
    for(var i=0;i<this.data.length;i++)
    {
        
        
        if((this.id===this.data[i].id)&&(this.password===this.data[i].password))
        {
          
          this.temp=1;
          
        }
    }
        
        if(this.temp===1)
        {
          alert("Login successful");
          
        }
        else
        {
          alert('Login failed');
        }
    }
 }



