import { NgModule } from '@angular/core';
import { RouterModule,Routes } from '@angular/router';
import{LoginComponent} from './login/login.component';
import{InsuranceTypeComponent} from './insurance-type/insurance-type.component';

const routes:Routes=[
    {path:'login',component:LoginComponent},
    {path:'insurance',component:InsuranceTypeComponent}
  ];
@NgModule({
  exports: [
    RouterModule
  ],
  imports:[RouterModule.forRoot(routes)]
})
export class AppRoutingModule 
{
  
}
