import { Component, OnInit } from '@angular/core';
import {AppService} from '../app.service';
import {NgxPaginationModule} from 'ngx-pagination';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(private _http:AppService) { }

  details:any=[];
  temp:any=0;
 

  ngOnInit() 
  {
    this._http.getfile().subscribe(data=>{
      this.details=data;
      console.log(this.details);
    }
    )

}

delete(name)
{
  //console.log("index is "+index);
  console.log("id is "+name);
  let index;
  this._http.deleteList(name).subscribe();
  for(var i=0;i<this.details.length;i++)
  {
    if(this.details[i].name==name)
    {
      index=i;
    }
  }
  this.details.splice(index,1);
}

add()
{
  this.temp=1;
}

dataEdit(id,name,des,price)
{
    //alert(id+name+des+price);
    this._http.originalData(id,name,des,price);
}

deleteAll()
{
  var c=confirm("Are you sure want to delete all list")
  
  if(c==true)
  {
  this._http.deleteAllData(this.details.length).subscribe();
  this.details=[];
  }
}

}
