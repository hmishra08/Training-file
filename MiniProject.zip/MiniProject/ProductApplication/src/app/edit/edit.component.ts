import { Component, OnInit } from '@angular/core';
import {AppService} from '../app.service';
import { RouterModule,Routes,Router } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  constructor(private _http:AppService,private router:Router) { }
 
  fid:any;
  id:any;
  name:any;
  des:any;
  price:any;
  b:any;
  ngOnInit() 
  {
   
   this.b=this._http.DataEdit();
   this.fid=this.b.id;
   this.id=this.b.id;
   this.name=this.b.name;
   this.des=this.b.des;
   this.price=this.b.price;
  //console.log(this.b);
    //this.b.id=this.id;
    //this.b.name=this.name;
    //this.b.des=this.des;
    //this.b.price=this.price;
    //console.log(this.id+this.name);
  }

  editList()
  {
    this._http.editData(this.fid,this.id,this.name,this.des,this.price).subscribe(data => {
                        this.router.navigate(["/product-list"]);
                        console.log(data);
                      });
  }

  clearList()
{
  /*this.id=null;
  this.name=null;
  this.des=null;
  this.price=null;*/
  this.router.navigate(["/product-list"]);
}

}
