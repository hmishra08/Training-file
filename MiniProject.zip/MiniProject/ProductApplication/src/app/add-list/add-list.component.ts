import { Component, OnInit } from '@angular/core';
import {AppService} from '../app.service';
import { RouterModule,Routes,Router } from '@angular/router';

@Component({
  selector: 'app-add-list',
  templateUrl: './add-list.component.html',
  styleUrls: ['./add-list.component.css']
})
export class AddListComponent implements OnInit {

  constructor(private _http:AppService,private router:Router) { }

  id:any;
  name:string;
  des:any;
  price:any;

  ngOnInit() {
  }

  addList()
  {
    if(this.id==null||this.id>9999)
    {
      alert("id can not be empty and be of 4 digit");
    }
    else
    {
          //alert(this.name.charCodeAt(0));     
          if(this.name==null)
          {
              alert("name can not be empty");
          }
          else
          {
            if(!(this.name.charCodeAt(0)>=65 && this.name.charCodeAt(0)<=90))
            {
              alert("first letter should be upper case");
            }
            else
            {
                if(this.des==null)
                {
                  alert("description can not be empty");
                }
                else
                {
                    if(this.price==null)
                    {
                      alert("price can not be empty");
                    }
                    else
                    {
                      this._http.addData(this.id,this.name,this.des,this.price).subscribe(data => {
                        this.router.navigate(["/product-list"]);
                        console.log(data);
                      });
                      
                    }
                }
            }
          }
    /*else
    {
    this._http.addData(this.id,this.name,this.des,this.price).subscribe();
    this.router.navigate(["/product-list"]);
    }*/
    }
  }

clearList()

{
  this.id=null;
  this.name=null;
  this.des=null;
  this.price=null;
  this.router.navigate(["/product-list"]);
}
 /* home()
  {
    this.router.navigate(["/product-list"]);
  }*/

}
