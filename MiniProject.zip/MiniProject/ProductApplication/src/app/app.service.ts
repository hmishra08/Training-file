import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import { RouterModule,Routes,Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private _http:HttpClient,private router:Router) { }

  Id:any;
  Name:any;
  Des:any;
  Price:any;

  originalData(id,name,des,price)
  {
    //alert(id+name+des+price);
    this.Id=id;
    this.Name=name;
    this.Des=des;
    this.Price=price;
  }

  DataEdit()
  {
    //alert(this.Id);
    return(
      {
        id:this.Id,
        name:this.Name,
        des:this.Des,
        price:this.Price
      }
      );
  }


  getfile()
  {
    //alert("get file called");
    return this._http.get("http://localhost:1234/display");
  }

  deleteList(name1)
  {
     //console.log("id to be deleted="+name1);
     var c=confirm("Are you sure want to delete data");
    if(c==true)
    {
    return this._http.post("http://localhost:1234/delete",{name:name1});
    }
    
      
  }

  addData(Id:number,Name,Des,Price)
  {
    //alert("addData in service is called");
    var c=confirm("Are you sure want to submit data");
    if(c==true)
    {
    return this._http.post("http://localhost:1234/add",{id:Id,name:Name,des:Des,price:Price});
    }
    
  }

  editData(fId,Id,Name,Des,Price)
  {
    //alert(Id+Name+Des+Price);
    //alert("editData in service is called");
    var c=confirm("Are you sure want to update data");
    if(c==true)
    {
    return this._http.post("http://localhost:1234/edit",{id1:{id:fId},id2:{id:Id,name:Name,des:Des,price:Price}});
    }
    
  }

  deleteAllData(totalLength)
  {
    alert(totalLength);
    return this._http.post("http://localhost:1234/deleteAll",{length:totalLength});
  }
}
