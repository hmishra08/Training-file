import { Component, OnInit,Input } from '@angular/core';
import {AppServiceService} from '../app-service.service';

@Component({
  selector: 'app-question4',
  templateUrl: './question4.component.html',
  styleUrls: ['./question4.component.css']
})
export class Question4Component implements OnInit {

  constructor(private ques4service:AppServiceService) { }
  ques4:any;
  answer4:string;
  @Input() Score4:number;
  temp:number=0;
  next:number=0;
  ngOnInit() 
  {
    this.ques4service.getfile('/assets/question4.json').subscribe(data=>{this.ques4=data
      //alert(this.ques1.ques);
      //alert(this.ques1.options);
      this.answer4=this.ques4.answer;
  });
}
f2(x)
{
  this.temp=1;
  //alert(x);
  if(x==this.answer4)
  {
    this.Score4=this.Score4+1;
    
  }
  //alert("Score is "+this.Score4);
}
f3()
{
  if(this.temp==1)
  {
    this.next=1;
  }
  else
  {
    alert("please select the option");
  }
}

}
