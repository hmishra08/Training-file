import { Component, OnInit } from '@angular/core';
import {AppServiceService} from '../app-service.service';

@Component({
  selector: 'app-rules',
  templateUrl: './rules.component.html',
  styleUrls: ['./rules.component.css']
})
export class RulesComponent implements OnInit {

  constructor(private ruleservice:AppServiceService) { }
  lists:any;
  check:number=0;
  temp:number=0;
  score:number=0;
  ngOnInit() 
  {
    this.ruleservice.getfile('/assets/rules.json').subscribe(data=>(this.lists=data));
  }
  f2()
  {
    this.check=1;
    //alert(this.check);
  }
  f3()
  {
    if(this.check==1)
    {
        this.temp=1;
    }
    else
    {
      alert("Please check the checkbox to proceed to quiz");
    }
  }
}
