import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import{Observable} from 'rxjs';



export class AppServiceService {

  constructor(private _http:HttpClient) { }




public  readData():Observable<object>
  {
      return this._http.get("http://localhost:1234/rest/api/readByname");
  }
}
