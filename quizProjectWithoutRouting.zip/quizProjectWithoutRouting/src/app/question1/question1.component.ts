import { Component, OnInit,Input } from '@angular/core';
import {AppServiceService} from '../app-service.service';

@Component({
  selector: 'app-question1',
  templateUrl: './question1.component.html',
  styleUrls: ['./question1.component.css']
})

export class Question1Component implements OnInit {

  constructor(private ques1service:AppServiceService) { }
  ques1:any;
  answer1:string;
  @Input() Score1:number;
  temp:number=0;
  next:number=0;
  ngOnInit() 
  {
    this.ques1service.getfile('/assets/question1.json').subscribe(data=>{this.ques1=data
      //alert(this.ques1.ques);
      //alert(this.ques1.options);
      this.answer1=this.ques1.answer;
  });
}
f2(x)
{
  //alert("score is "+this.Score);
  this.temp=1;
  //alert(x);
  if(x==this.answer1)
  {
    this.Score1+=1;
  }
  //alert("Score is "+this.Score1);
}
f3()
{
  if(this.temp==1)
  {
    this.next=1;
  }
  else
  {
    alert("please select the option");
  }
}

}
