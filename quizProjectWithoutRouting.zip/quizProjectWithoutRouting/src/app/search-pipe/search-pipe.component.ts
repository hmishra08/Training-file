import { Component, OnInit } from '@angular/core';
import{ProductFilterPipe} from './pipe';

@Component({
  selector: 'app-search-pipe',
  templateUrl: './search-pipe.component.html',
  
  styleUrls: ['./search-pipe.component.css'],
  
})
export class SearchPipeComponent implements OnInit {

  name:string;
  data:string[]=["toyata","maruti","audi","honda"];

  constructor() { }

  ngOnInit() {
  }

}
