import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
    name: 'productFilter'
})
export class ProductFilterPipe implements PipeTransform {
 
  List:string[]=[];
 transform(value: string[], args: string):
string[] {
    
        
       /* let firstLetter=args.charAt(0);
        
        for(var i=0;i<value.length;i++)
        {
            if(value[i].charAt(0)==firstLetter)
            {
                    this.List.push(value[i]);
            }
        }
      return this.List;*/




      return value.filter((args)=>{
          var abc=args.charAt(0);
          for(var i=0;i<value.length;i++)
        {
            if(value[i].charAt(0)==abc)
            {
                    return value[i];
            }
        }
      })
}
}