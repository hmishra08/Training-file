import { NgModule } from '@angular/core';
import { RouterModule,Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RulesComponent } from './rules/rules.component';
import { Question1Component } from './question1/question1.component';
import { Question2Component } from './question2/question2.component';
import { Question3Component } from './question3/question3.component';
import { Question4Component } from './question4/question4.component';
import { Question5Component } from './question5/question5.component';
import { Question6Component } from './question6/question6.component';

const routes:Routes=[
  {path:'login',component:LoginComponent},
  {path:'rules',component:RulesComponent},
  {path:'question1',component:Question1Component},
  //{path:'question2',component:Question2Component},
  //{path:'question3',component:Question3Component},
  //{path:'ques4',component:Question4Component},
  //{path:'ques5',component:Question5Component},
  //{path:'ques6',component:Question6Component}
]

@NgModule({
  exports:[RouterModule],
  imports: [
    RouterModule.forRoot(routes)
  ],
  
})
export class AppRoutingModule { }
