import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import{InsuranceTypeComponent} from './insuranceType/insurance-type.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginpageComponent,
    InsuranceTypeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
