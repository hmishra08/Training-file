import { Component, OnInit } from '@angular/core';
declare var $:any;
@Component({
  selector: 'app-insurance-type',
  templateUrl: './insurance-type.component.html',
  styleUrls: ['./insurance-type.component.css']
})
export class InsuranceTypeComponent implements OnInit {

  constructor() { }
  info:any[];
  select:any;
  ngOnInit() {
    $.get('src/app/insuranceType/insurance.json',(d,r)=>{
      this.info=d.type;
      console.log(this.info);
    })
  }
  page3()
  {
    
  }
  
  
  
//adding the json data
//type:string[]=["Home Insurance","Car insurance", "other Insurance"];

}
