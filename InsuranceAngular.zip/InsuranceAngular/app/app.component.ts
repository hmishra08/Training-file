import { Component } from 'angular2/core';
import{LoginpageComponent} from '../app/loginpage/loginpage.component'
@Component({
  selector: 'pm-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'insurance';
}
