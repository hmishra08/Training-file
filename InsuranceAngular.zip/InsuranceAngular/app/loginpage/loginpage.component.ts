import { Component,OnInit} from 'angular2/core';
import{InsuranceTypeComponent} from '../insuranceType/insurance-type.component'
declare var $:any;
@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css'],
  directives:[InsuranceTypeComponent]
})
export class LoginpageComponent{

  constructor() { }

  
 id:string;
 password:string;
 temp:number=0;
 data:any[]=[
   /*{id:"a1", password:"aaa111"},
   {id:"a2", password:"aaa222"},
   {id:"a3", password:"aaa333"},
   {id:"a4", password:"aaa444"},*/
 ]
 ngOnInit(){
   $.get('src/app/loginpage/loginDetail.json',(d,r:any)=>{
          this.data=d;
   })
   console.log(this.data);
 }
 f1()
 {
    for(var i=0;i<this.data.length;i++)
    {
        console.log(this.data[i].id);
        console.log(this.data[i].password);
        console.log(this.id);
        console.log(this.password);
        
        if((this.id===this.data[i].id)&&(this.password===this.data[i].password))
        {
          
          this.temp=1;
          
        }
    }
        console.log(this.temp);
        if(this.temp===1)
        {
          alert("Login successful");
          
        }
        else
        {
          alert('Login failed');
        }
    }
 }

