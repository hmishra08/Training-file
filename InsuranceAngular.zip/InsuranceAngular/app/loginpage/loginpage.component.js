System.register(['angular2/core', '../insuranceType/insurance-type.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, insurance_type_component_1;
    var LoginpageComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (insurance_type_component_1_1) {
                insurance_type_component_1 = insurance_type_component_1_1;
            }],
        execute: function() {
            LoginpageComponent = (function () {
                function LoginpageComponent() {
                    this.temp = 0;
                    this.data = [];
                }
                LoginpageComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    $.get('src/app/loginpage/loginDetail.json', function (d, r) {
                        _this.data = d;
                    });
                    console.log(this.data);
                };
                LoginpageComponent.prototype.f1 = function () {
                    for (var i = 0; i < this.data.length; i++) {
                        console.log(this.data[i].id);
                        console.log(this.data[i].password);
                        console.log(this.id);
                        console.log(this.password);
                        if ((this.id === this.data[i].id) && (this.password === this.data[i].password)) {
                            this.temp = 1;
                        }
                    }
                    console.log(this.temp);
                    if (this.temp === 1) {
                        alert("Login successful");
                    }
                    else {
                        alert('Login failed');
                    }
                };
                LoginpageComponent = __decorate([
                    core_1.Component({
                        selector: 'app-loginpage',
                        templateUrl: './loginpage.component.html',
                        styleUrls: ['./loginpage.component.css'],
                        directives: [insurance_type_component_1.InsuranceTypeComponent]
                    }), 
                    __metadata('design:paramtypes', [])
                ], LoginpageComponent);
                return LoginpageComponent;
            }());
            exports_1("LoginpageComponent", LoginpageComponent);
        }
    }
});
//# sourceMappingURL=loginpage.component.js.map