import{Injectable} from '@angular/core';
//import{IProduct} from './Product';
import{Http,Response} from '@angular/http';
import { Observable, of } from 'rxjs';

@Injectable()
export class ProductService{
    private _productUrl='api/products/products.json';
    constructor(private _http:Http){}
    getProducts():Observable<any>{
        return this._http.get(this._productUrl)
        .map(res=><any[]>res.json())
        .do(data=>console.log("All"+JSON.stringify(data)))
        .catch(this.handleError);
    }
    private handleError(error:Response){
        console.log(error);
    }
}