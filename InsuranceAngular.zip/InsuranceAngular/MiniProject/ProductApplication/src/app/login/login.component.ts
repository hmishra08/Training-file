import { Component, OnInit } from '@angular/core';
import {AppService} from '../app.service';
import { RouterModule,Routes,Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private _http:AppService,private router:Router) { }


  id:any;
  passwd:any;
  ngOnInit() 
  {
  }

  login()
  {
       
        this._http.login(this.id,this.passwd).subscribe(data=>{
          console.log(data);
          if(data[0]!=null)
          {
            
            alert("Login Successful");
            this.router.navigate(["/product-list"]);
          }
          else
          {
            alert("Login Unsuccessful");
          }
        });
  }

}
