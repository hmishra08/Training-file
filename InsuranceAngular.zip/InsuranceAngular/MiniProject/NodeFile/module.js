var express=require('express');
var app=express();
var fr=require('fs');
var MongoClient=require('mongodb').MongoClient;
var cors=require('cors');
var parser = require('body-parser');

function f1()
{
    var data=JSON.parse(fr.readFileSync('data.json'));
    MongoClient.connect('mongodb://localhost:27017/emp',function(err,dbvar){
        if(err) throw err;
        var coll=dbvar.db('product');
        coll.collection('productList').insert(data,true,function(err,value){
            if(err) throw err;
            console.log("document loaded in database");
            dbvar.close();
        })
        dbvar.close();
    })
}

//f1();

function f2()
{
    var data=JSON.parse(fr.readFileSync('login.json'));
    MongoClient.connect('mongodb://localhost:27017/emp',function(err,dbvar){
        if(err) throw err;
        var coll=dbvar.db('login');
        coll.collection('loginList').insert(data,true,function(err,value){
            if(err) throw err;
            console.log("document loaded in database");
            dbvar.close();
        })
        dbvar.close();
    })
}

f2();




app.get('/display',(req,res)=>{
    
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    MongoClient.connect('mongodb://localhost:27017/emp',function(err,dbvar){
        if(err) throw err;
        var coll=dbvar.db('product');
        coll.collection('productList').find().toArray(function(err,value){
            if(err) throw err;
            else
            {
                console.log(value);
                res.send(value);
            }
            dbvar.close();
        });
        dbvar.close();
    })
})

app.use(parser.json());

app.post('/delete',(req,res)=>{
    
    
    console.log(req.body);
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    MongoClient.connect('mongodb://localhost:27017/emp',{ useNewUrlParser: true },function(err,dbvar){
        if(err) throw err;
        var coll=dbvar.db('product');
        coll.collection('productList').deleteOne(req.body,function(err,value){
            if(err) throw err;
            else
            {
                console.log("1 document deleted");
                
            }
            dbvar.close();
        });
        dbvar.close();
    })
})

app.post('/add',(req,res)=>{
    
    
    console.log(req.body);
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    MongoClient.connect('mongodb://localhost:27017/emp',{ useNewUrlParser: true },function(err,dbvar){
        if(err) throw err;
        var coll=dbvar.db('product');
        coll.collection('productList').insert(req.body,true,function(err,value){
            if(err) throw err;
            else
            {
                console.log("1 document inserted");
                res.send(value);
                
            }
            dbvar.close();
        });
        dbvar.close();
    })
})


app.post('/edit',(req,res)=>{
    
    
    console.log(req.body);
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    MongoClient.connect('mongodb://localhost:27017/emp',{ useNewUrlParser: true },function(err,dbvar){
        if(err) throw err;
        var coll=dbvar.db('product');
        coll.collection('productList').update(req.body.id1,{$set:req.body.id2},true,function(err,value){
            if(err) throw err;
            else
            {
                console.log("1 document updated");
                res.send(value);
                
            }
            dbvar.close();
        });
        dbvar.close();
    })
})

app.post('/deleteAll',(req,res)=>{
    
    
    console.log(req.body);
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    MongoClient.connect('mongodb://localhost:27017/emp',{ useNewUrlParser: true },function(err,dbvar){
        if(err) throw err;
        var coll=dbvar.db('product');
        for(var i=0;i<=req.body.length;i++)
        {
        coll.collection('productList').deleteMany({},function(err,value){
            if(err) throw err;
            else
            {
                console.log("1 document deleted");
                res.send(value);
            }
            dbvar.close();
        });
        }
        dbvar.close();
    })
})


app.post('/login',(req,res)=>{
    var temp=0;
    //console.log(req.body);
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-Width,Content-Type,Accept");
    MongoClient.connect('mongodb://localhost:27017/emp',function(err,dbvar){
        if(err) throw err;
        var coll=dbvar.db('login');
        coll.collection('loginList').find(req.body).toArray(function(err,value){
            if(err) throw err;
            else
            {
            console.log(value);
            res.send(value);
            }
            /*else
            {
                //console.log(value.length);
               // console.log(value[0].id);
                for(var i=0;i<value.length;i++)
                {
                   //console.log(i);
                  // console.log(value[i].id);
                    if(value[i].id==req.body.Id.id && value[i].passwd==req.body.Passw.passwd)
                    {
                         //console.log("Login succssesful");
                        //res.send(1);
                        temp=1;
                       break;
                    }
                    
                }
                if(temp==1)
                {
                 console.log("Login succssesful");
                        res.send(value);   
                }
                /*else
                {
                    console.log("Login Unsuccssesful");
                        res.send(0);   
                }
                
        }*/
            dbvar.close();
        });
        dbvar.close();
    })
})


        
app.use(cors()).listen(1234,()=>{
    console.log("running")
})