
var students=[{
    name:"Himanshu",
    mob:9896239324,
    Address:"unknown",
},
{
    name:"Uday",
    mob:9896239324,
    Address:"unknown",
}
];
db.user.insert(students);
