var Pid,Pname,Pprice;
            var arrayProduct=[];
            
var product=function addtopraoduct(id,name,price)
{
    this.Pid=id;
    this.Pname=name;
    this.Pprice=price;
    
}
setallprod=function(prod){
    arrayProduct.push(prod);
}

var product1=new product(1,"Himanshu",20);
//product1.getdata();
var product2=new product(2,"abc",30);
var product3=new product(3,"def",10);
var product4=new product(4,"ghi",40);
var product5=new product(5,"jkl",50);
setallprod(product1);
setallprod(product2);
setallprod(product3);
setallprod(product4);
setallprod(product5);
sortByPrice=function(oneprod,twoprod){
    if(oneprod.Pprice>twoprod.Pprice) return 1;
    if(oneprod.Pprice===twoprod.Pprice) return -1;
    return 0;
}
display=function(){
    for(var i=0;i<arrayProduct.length;i++)
    {
        console.log(arrayProduct[i].Pid);
        console.log(arrayProduct[i].Pname);
        console.log(arrayProduct[i].Pprice);
        
    }
}
display();
deletall=function(id){
    for(var i=0;i<5;i++)
    {
        if(arrayProduct[i].Pid==id){
            arrayProduct.splice(i,1);
            break;
        }
    }
}
deletall(5);
display();
for(var i=0;i<arrayProduct.length-1;i++)
{
    
    

























    arrayProduct.sort(sortByPrice);
}

display();
