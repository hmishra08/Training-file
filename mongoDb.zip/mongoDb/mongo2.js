var detail=[{
    _id:1,
    item:"Laptop",
    prodCat :"Electronics",
    price:30000.0,
    quantity: 2,
    orderInfo:{
        _id:"O001",
        orderdate: ISODate("2014-01-01"),
        address:{
            street:"66,Airoli",
            city:"Mumbai",
            state:"MS",
            zipcode:700987,
            coords: [ -73.856077, 40.848447 ]
        },
        email:"capgemini@capgemini.com",
        mobiles:[8888108810],

}},
{ 
    _id:2,
    item:"Mobile",
    prodCat :"Electronics",
    price:15000.0,
    quantity: 10,
    orderInfo:{
        _id:"O002",
        orderdate : ISODate("2010-03-12"),
        address:{
            street:"FC Road",
            city:"Pune",
            state:"MS",
            zipcode:40081,
            coords: [ -23.80007, 30.1123456 ]
        },
        email:"icres@ibm.com",
        mobiles:[9856342189]
    }},
{ 
    _id:5,
    item:"TV",
    prodCat :"Electronics",
    price:24000.0,
    quantity: 10,
    orderInfo:{
        _id:"O003",
        orderdate : ISODate("2012-06-17"),
        address:{
            street:"GT Road",
            city:"Sahibabad",
            state:"UP",
            zipcode:567777,
            coords: [ -11.80007, 13.1123456 ]
        },
        email:"techm@techm.com",
        mobiles:[7865452222]
    }},
    { 
        _id:6,
        item:"Bangles",
        prodCat :"Jewellery",
        price:4000.0,
        quantity: 1,
        orderInfo:{
            _id:"O004",
            orderdate : ISODate("2010-05-16"),
            address:{
                street:"Salt Lake",
                city:"Kolkata",
                state:"West Bengol",
                zipcode:222224,
                coords: [ -67.850007, 9.456666 ]
            },
            email:"vaishali@gmail.com",
            mobiles:[8888108850,9402312123]
        }},
        { 
        _id:7,
        item:"Bangles",
        prodCat :"Jewellery",
        price:4000.0,
        quantity: 1,
        orderInfo:{
            _id:"O004",
            orderdate : ISODate("2010-05-16"),
            address:{
                street:"Salt Lake",
                city:"Kolkata",
                state:"West Bengol",
                zipcode:222224,
                coords: [ -67.850007, 9.456666 ]
            },
            email:"vaishali@gmail.com",
            mobiles:[8888108850,9402312123]
        }},
];
db.ProductCollection.insert(detail);