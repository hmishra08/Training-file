var Express = require('express');
 var multer = require('multer');
 var bodyParser = require('body-parser');
 var app = Express();
 app.use(bodyParser.json());

var adId;

 var Storage = multer.diskStorage({
     destination: function(req, file, callback) {
         callback(null, "./Images");
         
     },
     filename: function(req, file, callback) {
         callback(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
        // console.log(file);
     }
     
 });

 
function f1(){
console.log(Storage.filename);
}




 var upload = multer({
     storage: Storage
 }).array("imgUploader", 1); //Field name and max count



 app.get("/", function(req, res) {
     //console.log(req.params.id);
     res.sendFile(__dirname + "/src/app/upload/upload.component.html");
 });



// app.post("/image",function(req,res){
//         console.log(req.body);
// })
 
 
 app.post("/api/Upload", function(req, res) {
     console.log(req.body);
     upload(req, res, function(err) {
         if (err) {
             return res.end("Something went wrong!");
         }
        //  var originalFileName = req.file.originalname
        console.log(req.files[0].filename);
         res.redirect("http://localhost:4200");
         
         return res.end("your image is uploaded succesfully");
         
 });
 });




// app.post("/submit",function(req,res){
//         console.log(Storage.filename);
// })


 app.listen(8000, function(a) {
     console.log("Listening to port 8000");
 })