
//function for assigning module options
function dom()
{
    var emp=document.getElementById("domain").value;
    if(emp==="JEE")
    {
        document.getElementById("module").innerHTML="<option>Core Java</option><option>Servlet-JSP</option><option>Spring</option>";
    }
    else if(emp===".NET")
    {
        document.getElementById("module").innerHTML="<option>C#</option><option>ADO.NET</option><option>ASP.NET</option>";
    }
}

//function for calculating total score
function calc()
{
    var mpt=document.getElementById("mpt").value;
    var mtt=document.getElementById("mtt").value;
    var ass=document.getElementById("ass").value;
    var mpt1=parseInt(mpt);
    var mtt1=parseInt(mtt);
    var ass1=parseInt(ass);
    var total=mpt1+mtt1+ass1;//(total score is calculated by adding all the scores)
    alert("Total Module Score "+total);
    
}