function product(){
    this.Pid=prompt("enter the id");
    this.Pname=prompt("enter the name");
    this.Price=prompt("enter the price");
    this.Pdes=prompt("enter the description");
    this.printAllProduct(){
        console.log("Pid= "+Pid+" Pname= "+Pname+" Price= "+Price+" Description= "+Pdes);
    }
}
var obj=new product();