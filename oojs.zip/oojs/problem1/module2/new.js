
function f1()
            {
                var total=0;
                var list=document.getElementsByName("hobbies")
                
                for(var i=0;i<list.length;i++)
                {
                    if(list[i].checked==true)
                    {
                        total=total+1;
                    }
                }
                console.log(total);
                var prom=document.getElementById("promo").value;
                var subprom=prom.substring(3,5);
                var num=parseInt(subprom);
                console.log(num);
                if(total<2)
                {
                    
                    alert("select at least 2 hobbies");
                    return false;
                    
                }
                else
                {
                    if(num%7!=0)
                    {
                        alert("Last 3 digit of prompcode should be divisible by 7");
                        return false;
                    }
                    else
                    {
                    if(confirm("Are you would like to submit")) 
                    {
                        alert("Your form are submitted");
                    } 
                    else {
                        }
                    }
                }
            }
        function f2()
        {
            var prom=document.getElementById("promo").value;
            console.log(prom);
            var len=prom.length;

        }