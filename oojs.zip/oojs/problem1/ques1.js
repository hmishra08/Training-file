var pId,pName,Pprice,index=0,de,i,lu;
var productarray=[];
var product=function(pid,pname,price){
        this.pId=pid;
        this.pName=pname;
        this.Pprice=price;
    }

function f1()
{
    document.getElementById("modify1").style.display="block";
    var pid=document.getElementById("pid").value;
    var pname=document.getElementById("pname").value;
    var price=document.getElementById("pprice").value;
    
    var productnew=new product(pid,pname,price);
    productarray.push(productnew);
    
    document.getElementById("data").innerHTML+="<tr><td>"+productarray[index].pId+"</td><td>"+productarray[index].pName+"</td><td>"+productarray[index].Pprice+"</td><td><input type='button' class='btn btn-warning' value='Delete' onclick='del(this)'></td><td><input type='button' value='Update' onclick='upd(this)' class='btn btn-info'></td></tr></table>";
    
    index++;
}
function del(r)
{
    var l=  r.parentNode.parentNode.rowIndex;
    productarray.splice(l,1);
    document.getElementById("data").deleteRow(l);
    console.log(l);
}
function upd(r)
{
    document.getElementById("modify2").style.display="block";
    document.getElementById("update").innerHTML="<form role='form'><div class='form-group'><table class='table table-striped table-bordered table-hover table-responsive'><tr><td>ProductId</td><td><input type='text' name='updateid' id='updateid' value='' class='form-control'></td></tr><tr><td>ProductName</td><td><input type='text' name='updatename' id='updatename' class='form-control'></td></tr><tr><td>ProductPrice</td><td><input type='text' name='updateprice' id='updateprice' class='form-control'></td></tr></table><input type='button' onclick='updated()' value='Update Data' class='btn btn-success form-control'></div></form>"
    lu=  r.parentNode.parentNode.rowIndex;
    document.getElementById("updateid").value=productarray[lu].pId;
    document.getElementById("updatename").value=productarray[lu].pName;
    document.getElementById("updateprice").value=productarray[lu].Pprice;
    console.log(lu);
    
}
function updated()
{
    console.log(lu);
    var newid=document.getElementById("updateid").value;
    var newname=document.getElementById("updatename").value;
    var newprice=document.getElementById("updateprice").value;
        console.log(newid);
        console.log(newname);
        console.log(newprice);
        productarray[lu].pId=newid;
        productarray[lu].pName=newname;
        productarray[lu].Pprice=newprice;
        console.log(productarray[lu]);
    var mytable=document.getElementById("data");
    mytable.rows[lu].cells[0].innerHTML=newid;
    mytable.rows[lu].cells[1].innerHTML=newname;
    mytable.rows[lu].cells[2].innerHTML=newprice;
}